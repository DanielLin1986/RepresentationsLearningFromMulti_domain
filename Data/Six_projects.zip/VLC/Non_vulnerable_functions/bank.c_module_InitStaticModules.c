#else
static void module_InitStaticModules(void) { }
#endif
