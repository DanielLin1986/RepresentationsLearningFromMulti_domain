/* */
static int ScanSort( const char **ppsz_a, const char **ppsz_b )
{
    return strcmp( *ppsz_a, *ppsz_b );
}
