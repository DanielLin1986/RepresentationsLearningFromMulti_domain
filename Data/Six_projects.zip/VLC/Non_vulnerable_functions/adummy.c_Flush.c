}
static void Flush(audio_output_t *aout, bool wait)
{
    (void) aout; (void) wait;
}
